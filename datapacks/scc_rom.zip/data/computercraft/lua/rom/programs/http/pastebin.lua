-- Paste service definitions
local SERVICES = {{
  name = "p.sewers.cc",
  endpoint = "https://p.sewers.cc",
  color = colors.pink,
  patterns = {"^https?://p%.sewers%.cc/([%a%d]+)$", "^p%.sewers%.cc/([%a%d]+)$",
              "^https?://p%.sewers%.cc/([%a%d]+)/raw/?$", "^p%.sewers%.cc/([%a%d]+)/raw/?$"},
  rawUrl = function(code)
    return "https://p.sewers.cc/" .. textutils.urlEncode(code) .. "/raw"
  end,
  identifyByLength = function(len)
    return len == 10
  end
}, {
  name = "p.reconnected.cc",
  endpoint = "https://p.reconnected.cc",
  color = colors.yellow,
  patterns = {"^https?://p%.reconnected%.cc/([%a%d]+)$", "^p%.reconnected%.cc/([%a%d]+)$",
              "^https?://p%.reconnected%.cc/raw/([%a%d]+)$", "^p%.reconnected%.cc/raw/([%a%d]+)$"},
  rawUrl = function(code)
    return "https://p.reconnected.cc/raw/" .. textutils.urlEncode(code)
  end,
  identifyByLength = function(len)
    return len == 9
  end
}, {
  name = "p.sc3.io",
  endpoint = "https://p.sc3.io",
  color = colors.orange,
  patterns = {"^https?://p%.sc3%.io/([%a%d]+)$", "^p%.sc3%.io/([%a%d]+)$",
              "^https?://p%.sc3%.io/api/v1/pastes/([%a%d]+)/?.*$", "^p%.sc3%.io/api/v1/pastes/([%a%d]+)/?.*$"},
  rawUrl = function(code)
    return "https://p.sc3.io/api/v1/pastes/" .. textutils.urlEncode(code) .. "/raw"
  end,
  identifyByLength = function(len)
    return len ~= 8 and len ~= 9 and len ~= 10
  end
}, {
  name = "pastebin.com",
  endpoint = "https://pastebin.com",
  color = colors.yellow,
  patterns = {"^https?://pastebin%.com/([%a%d]+)$", "^pastebin%.com/([%a%d]+)$",
              "^https?://pastebin%.com/raw/([%a%d]+)$", "^pastebin%.com/raw/([%a%d]+)$"},
  rawUrl = function(code)
    return "https://pastebin.com/raw/" .. textutils.urlEncode(code)
  end,
  identifyByLength = function(len)
    return len == 8
  end
}}

local function printUsage()
  local programName = arg[0] or fs.getName(shell.getRunningProgram())
  print("Usages:")
  print(programName .. " put <filename>")
  print(programName .. " get <code> <filename>")
  print(programName .. " run <code> <arguments>")
  print(programName .. " unset")
  print(programName .. " set <api_key>")
end

local tArgs = {...}
if #tArgs < 1 then
  printUsage()
  return
end

if not http then
  printError("Pastebin requires the http API, but it is not enabled")
  printError("Set http.enabled to true in CC: Tweaked's server config")
  return
end

local function writeCol(color, text)
  if term.isColor() then term.setTextColor(color) end
  write(text)
end

--- Attempts to extract paste ID and determine service from code/URL
local function extractPasteInfo(paste)
  -- First try pattern matching
  for _, service in ipairs(SERVICES) do
    for _, pattern in ipairs(service.patterns) do
      local code = paste:match(pattern)
      if code then return service, code, service.rawUrl(code) end
    end
  end

  -- If no pattern matched, try raw ID with length-based detection
  local rawCode = paste:match("^([%a%d]+)$")
  if rawCode then
    for _, service in ipairs(SERVICES) do
      if service.identifyByLength(#rawCode) then return service, rawCode, service.rawUrl(rawCode) end
    end
  end

  return nil, nil, nil
end

local function printTryAgain(errResponse)
  if errResponse then
    local headers = errResponse.getResponseHeaders()
    if headers["Retry-After"] then printError("Try again in " .. headers["Retry-After"] .. " seconds...") end
  end
end

local function get(url)
  local service, paste, rawUrl = extractPasteInfo(url)
  if not service then
    io.stderr:write("Invalid paste code.\n")
    io.write("The code should be a valid URL or ID from p.sewers.cc, p.reconnected.cc, p.sc3.io, or pastebin.com\n")
    return
  end

  writeCol(colors.lightGray, "Connecting to ")
  writeCol(service.color, service.name)
  writeCol(colors.lightGray, "... ")

  local headers = {}
  local apiKey = settings.get("sewers.api_key")
  if service.name == "p.sewers.cc" and apiKey then headers["Authorization"] = apiKey end

  -- Add cache buster for Pastebin spam protection
  local cacheBuster = ("%x"):format(math.random(0, 2 ^ 30))
  local response, err, errResponse = http.get(rawUrl .. "?cb=" .. cacheBuster, headers)

  if response then
    local responseHeaders = response.getResponseHeaders()
    -- Check for HTML content (indicates spam protection or error page)
    if responseHeaders["Content-Type"] and not responseHeaders["Content-Type"]:find("^text/plain") then
      printError("Failed.")
      response.close()

      if service.name == "pastebin.com" then
        printError(
            "Pastebin blocked the download due to spam protection. Please complete the captcha in a web browser: https://pastebin.com/" ..
                textutils.urlEncode(paste))
      else
        printError("Service returned an error page instead of paste content.")
      end
      return
    end

    writeCol(colors.green, "Success.\n")
    term.setTextColor(colors.white)

    local content = response.readAll()
    response.close()
    return content
  else
    printError("Failed.\n")
    printError(err or "Unknown error")
    printTryAgain(errResponse)
  end
end

local sCommand = tArgs[1]

if sCommand == "put" then
  -- Upload a file to sewers.cc
  local sFile = tArgs[2]
  if not sFile then
    printUsage()
    return
  end

  local sPath = shell.resolve(sFile)
  if not fs.exists(sPath) or fs.isDir(sPath) then
    printError("No such file")
    return
  end

  -- Read the file
  local sName = fs.getName(sPath)
  local file = fs.open(sPath, "r")
  if not file then
    printError("Could not open file")
    return
  end
  local sText = file.readAll()
  file.close()

  -- Show upload notice
  local w = term.getSize()
  term.setTextColor(colors.yellow)
  print(("\140"):rep(w))
  write("Info: ")
  term.setTextColor(colors.white)
  write("Uploading to ")
  writeCol(colors.pink, "p.sewers.cc")
  term.setTextColor(colors.white)
  print(".")
  term.setTextColor(colors.yellow)
  print(("\140"):rep(w) .. "\n")

  -- Upload to sewers.cc
  writeCol(colors.lightGray, "Connecting to ")
  writeCol(colors.pink, "p.sewers.cc")
  writeCol(colors.lightGray, "... ")

  local headers = {
    ["Content-Type"] = "application/json"
  }
  local sApiKey = settings.get("sewers.api_key")
  if sApiKey then headers["Authorization"] = sApiKey end

  local payload = textutils.serializeJSON({
    title = sName,
    language = "lua",
    content = sText,
    visibility = "unlisted"
  })

  local response, err, errResponse = http.post("https://p.sewers.cc/api/paste", payload, headers)

  if response then
    writeCol(colors.green, "Success.\n")
    term.setTextColor(colors.white)

    local responseText = response.readAll()
    response.close()

    local result = textutils.unserializeJSON(responseText)
    if result and result.code then
      local sCode = result.code
      writeCol(colors.white, "Uploaded as ")
      writeCol(colors.blue, "https://p.sewers.cc/" .. textutils.urlEncode(sCode) .. "\n")
      writeCol(colors.white, "Run \"")
      writeCol(colors.blue, "pastebin get " .. sCode)
      writeCol(colors.white, "\" to download anywhere\n")
    else
      printError("Invalid response from server")
    end
  else
    printError("Failed.\n")
    printError(err or "Unknown error")
    printTryAgain(errResponse)
  end

elseif sCommand == "get" then
  -- Download a file
  if #tArgs < 3 then
    printUsage()
    return
  end

  local sCode = tArgs[2]
  local sFile = tArgs[3]
  local sPath = shell.resolve(sFile)
  if fs.exists(sPath) then
    printError("File already exists")
    return
  end

  local res = get(sCode)
  if res then
    local file = fs.open(sPath, "w")
    if not file then
      printError("Could not create file")
      return
    end
    file.write(res)
    file.close()
    print("Downloaded as " .. sFile)
  end

elseif sCommand == "run" then
  if #tArgs < 2 then
    printUsage()
    return
  end

  local sCode = tArgs[2]
  local res = get(sCode)
  if res then
    local func, err = load(res, sCode, "t", _ENV)
    if not func then
      printError(err)
      return
    end
    local success, msg = pcall(func, select(3, ...))
    if not success then printError(msg) end
  end

elseif sCommand == "unset" then
  settings.unset("sewers.api_key")
  settings.save()
  print("API key unset")

elseif sCommand == "set" then
  local sApiKey = tArgs[2]
  if not sApiKey then
    printError("No API key provided")
    return
  end
  settings.set("sewers.api_key", sApiKey)
  settings.save()
  print("API key set")

else
  printUsage()
end
